export const personalData = {
  name: "PRASHANT RAJPOOT",
  profile: '/profile.png',
  designation: "Software Developer",
  description: "My name is PRASHANT RAJPOOT. I’m a passionate and enthusiastic Python Full Stack Developer with a focus on building scalable, efficient web applications. I specialize in backend development using Django, Django REST Framework, Flask, and FastAPI, and have experience with PostgreSQL and MongoDB. On the frontend, I work with React.js to create responsive and dynamic interfaces. I’m a quick learner with a strong problem-solving mindset and a drive to explore new technologies. I’m open to job opportunities that match my skills and interests in full stack development.",
  email: 'prashantrajpoot8859@gmail.com',
  phone: '+91 9084531771',
  address: 'Noida, Uttar Pradesh, India 201301',
  github: 'https://github.com/SoftEnggPrashant',
  facebook: '',
  linkedIn: 'https://www.linkedin.com/in/prashant-rajpoot-92b3071b2/',
  twitter: '',
  stackOverflow: '',
  leetcode: "https://leetcode.com/u/code_for_Prashant/",
  devUsername: "prashant_rajpoot_0e51a2b4",
  resume: "https://drive.google.com/file/d/1m6MbDMbLrR-R2h9s32tAw0PTaagYQcTF/view?usp=sharing"
}