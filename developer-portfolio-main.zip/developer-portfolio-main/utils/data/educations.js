export const educations = [
  {
    id: 1,
    title: "Full Stack Developer Certificate",
    duration: "2023 - 2024",
    institution: "Code Help by Babbar, Online",
  },
  {
    id: 2,
    title: "Master Degree",
    duration: "2021 - 2023",
    institution: "AKT University, Lucknow (India)",
  },
  {
    id: 3,
    title: "Bachelor Degree",
    duration: "2018 - 2021",
    institution: "CCS University, Meerut (India)",
  }
]