export const projectsData = [
    {
        id: 1,
        name: 'AI Powered Networking App',
        description: `AI-Powered Networking App is an intelligent platform that provides deep insights into network health, incidents, and compliance. It leverages AI to help teams proactively monitor, troubleshoot, and optimize network operations for maximum performance and reliability.`,
        tools: ['Flask',"Django REST Framework","PostgreSQL",'Mongodb',"OpenAI API","APScheduler","Redis","Docker"],
        role: 'Backend Developer',
        code: '',
        demo: '',
    },
    {
        id: 2,
        name: 'The Observer',
        description: `Observer is an all-in-one platform that integrates with various network tools (like Cisco Catalyst Center, SD-WAN, Meraki, ITSM tools, etc.) to provide role-based insights.
                    For CXOs, it delivers a high-level view of key KPIs—like efficiency, compliance, and strategy—enabling informed, data-driven decisions without technical deep dives.
                    For IT Heads, it offers detailed insights into network health, incidents, and compliance, helping them monitor and optimize operations effectively.
                    By customizing data and dashboards to user roles, Observer bridges strategic vision with operational execution.`,
        tools: ['Flask',"Django REST Framework","PostgreSQL",'Mongodb',"Google Maps","APScheduler","Redis","Docker","AWS S3","AWS EC2"],
        role: 'Backend Developer',
        code: '',
        demo: '',
    },
    {
        id: 3,
        name: 'vAutomate',
        description: `vAutomate is an advanced automation engine for network configuration management. This powerful tool streamlines network configurations from Day 0 to Day 2, employing sophisticated techniques for automation.
                    It's designed to significantly reduce human error, boost efficiency, and support scalable network operations. Adapting to changing network needs, vAutomate ensures operational consistency and maintains robust network infrastructures.`,
        tools: ["FastApi","Django REST Framework","PostgreSQL",'Mongodb',"APScheduler","Redis","Docker","AWS S3","AWS EC2",'React.js', 'Bootstrap'],
        code: '',
        role: 'Full Stack Developer',
        demo: '',
    },
    {
        id: 4,
        name: 'Education Tech Platform',
        description: `EdTech Platform is a role-based learning management system designed for seamless interaction between students and instructors, with secure Razorpay payment integration.
                    Students can browse courses, enroll in classes, track progress, download resources, and securely make payments via Razorpay. They receive real-time updates, certificates, and performance reports.
                    Instructors can create and manage courses, upload content (videos, PDFs, quizzes), track student engagement, and receive payments directly for their classes.
                    The platform ensures a smooth learning experience through:
                    1. Role-based dashboards for personalized access
                    2. Razorpay integration for secure one-time and subscription payments
                    3. Course progress tracking, notifications, and assessments
                    4. Admin panel for managing users, content, and transactions`,        
        tools: ["Django REST Framework","PostgreSQL","APScheduler","Redis","Docker",'React.js', 'TailwindCSS','Redux Toolkit','JWT','Razorpay','AWS S3'],
        code: '',
        demo: '',
        role: 'Full Stack Developer',
    }
];


// Do not remove any property.
// Leave it blank instead as shown below

// {
//     id: 1,
//     name: '',
//     description: "",
//     tools: [],
//     role: '',
//     code: '',
//     demo: '',
// },