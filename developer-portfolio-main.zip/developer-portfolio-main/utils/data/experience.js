export const experiences = [
  {
    id: 1,
    title: 'Software Engineer - (Python)',
    company: "Velocis Systems Private Ltd.",
    duration: "(Sep 2023 - Present)"
  },
  {
    id: 2,
    title: "FullStack Developer Intern",
    company: "Cutting Edge Digital Private Ltd.",
    duration: "(Oct 2022 - Apr 2023)"
  },
  {
    id: 3,
    title: "FullStack Developer",
    company: "Freelance",
    duration: "(Fab 2021 - Aug 2022)"
  }
]